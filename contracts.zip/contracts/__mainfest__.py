{
    'name': "contracts",
    'author': "GOLD PRO BUILDING CONSTRUCTION",
    'category': "Administration",
    'depends': ['base',
                ],
    'data': [

    ],
    'application': True
}